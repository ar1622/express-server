export type ILesson = {
  topic: string
  description: string
  price: number
  location: string
  space: number
}
