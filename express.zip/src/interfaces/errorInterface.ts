export type IErrorInterface = {
  path: string
  message: string
}
